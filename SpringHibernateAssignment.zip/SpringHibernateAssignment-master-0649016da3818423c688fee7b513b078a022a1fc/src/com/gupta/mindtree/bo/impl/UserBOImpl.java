package com.gupta.mindtree.bo.impl;

import java.util.List;

import com.gupta.mindtree.bo.UserBO;
import com.gupta.mindtree.dao.impl.UserDAOImpl;
import com.gupta.mindtree.model.User;

public class UserBOImpl implements UserBO{
	
	UserDAOImpl userDaoImpl;

	public void setUserDaoImpl(UserDAOImpl userDaoImpl) {
		this.userDaoImpl = userDaoImpl;
	}

	@Override
	public void save(User user) {
		userDaoImpl.save(user);
	}

	@Override
	public void update(User user) {
		userDaoImpl.update(user);
	}

	@Override
	public void delete(User user) {
		userDaoImpl.delete(user);
	}

	@Override
	public User findById(int id) {
		return userDaoImpl.findById(id);
	}

	@Override
	public List<User> getAll() {
		return userDaoImpl.getAll();
	}

	@Override
	public List<User> findByAggregateAndDepartment(int aggregate, String department) {
		return userDaoImpl.findByAggregateAndDepartment(aggregate, department);
	}

}
