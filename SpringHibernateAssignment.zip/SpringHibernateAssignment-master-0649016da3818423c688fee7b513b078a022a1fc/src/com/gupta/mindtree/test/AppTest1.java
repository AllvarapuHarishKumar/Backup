package com.gupta.mindtree.test;

import java.util.ArrayList;
import java.util.List;

import com.gupta.mindtree.bo.impl.UserBOImpl;
import com.gupta.mindtree.dao.impl.UserDAOImpl;
import com.gupta.mindtree.model.User;

public class AppTest1 {

	public static List<User> getUser(int start, int end) {
		List<User> users = new ArrayList<User>();
		for (int i = start; i <= end; i++) {
			User user = new User("firstName" + i, "lastName" + i, "department" + i, "location" + i, i,
					i % 2 == 0 ? "Yes" : "No");
			users.add(user);
		}
		return users;
	}

	public static void main(String[] args) {

		List<User> users = getUser(1, 10);

		UserDAOImpl userDAO = new UserDAOImpl();
		UserBOImpl userBO = new UserBOImpl();
		userBO.setUserDaoImpl(userDAO);

		for (User user : users) {
			userBO.save(user);
		}

		users = userBO.getAll();
		for (User user : users) {
			System.out.println(user.toString());
		}

		User user = userBO.findById(6);
		System.out.println(user.toString());

		user.setDepartment("UPDATED");
		userBO.update(user);

		user = userBO.findById(6);
		System.out.println(user.toString());
		System.out.println("---------------------------------------------");

		users = userBO.getAll();
		for (User u : users) {
			System.out.println(u.toString());
		}

		userBO.delete(user);
		System.out.println("---------------------------------------------");

		users = userBO.getAll();
		for (User u : users) {
			System.out.println(u.toString());
		}

	}

}
