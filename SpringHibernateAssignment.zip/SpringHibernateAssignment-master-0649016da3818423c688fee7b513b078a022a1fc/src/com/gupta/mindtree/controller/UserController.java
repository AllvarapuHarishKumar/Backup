package com.gupta.mindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.gupta.mindtree.bo.impl.UserBOImpl;
import com.gupta.mindtree.dao.impl.UserDAOImpl;
import com.gupta.mindtree.model.User;

@RestController
@RequestMapping(value="/user")
public class UserController {
	
	UserDAOImpl userDAO = new UserDAOImpl();
	UserBOImpl userBO = new UserBOImpl();
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public @ResponseBody Map addUser(@RequestBody User user) {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		userBO.save(user);
		map.put("message", "Added Successfully");
		return map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/getall", method=RequestMethod.GET)
	public @ResponseBody Map getAll() {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		map.put("users", userBO.getAll());
		map.put("message", "Data Fetched Successfully");
		return map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public @ResponseBody Map updateUser(@RequestBody User user) {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		userBO.update(user);
		map.put("message", "User Data Updated Successfully");
		return map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/getuser/{id}", method=RequestMethod.GET)
	public @ResponseBody Map getUser(@PathVariable(value="id") String id) {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		map.put("user", userBO.findById(Integer.parseInt(id)));
		map.put("message", "Data Fetched Successfully");
		return map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/get", method=RequestMethod.GET)
	public @ResponseBody Map getUserByAggregate(
			@RequestParam(name="aggregate") String aggregate,
			@RequestParam(name="department") String department) {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		map.put("users", userBO.findByAggregateAndDepartment(Integer.parseInt(aggregate), department));
		map.put("message", "Data Fetched Successfully");
		return map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/update/placed/{id}", method=RequestMethod.PUT)
	public @ResponseBody Map updateUserPlaced(@PathVariable(value="id") String id) {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		User user = userBO.findById(Integer.parseInt(id));
		user.setPlaced("Yes");
		userBO.update(user);
		map.put("message", "User Data Updated Successfully");
		return map;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	public @ResponseBody Map deleteUser(@PathVariable(value="id") String id) {
		Map map = new HashMap();
		userBO.setUserDaoImpl(userDAO);
		User user = userBO.findById(Integer.parseInt(id));
		userBO.delete(user);
		map.put("message", "User Data Deleted Successfully");
		return map;
	}

}
