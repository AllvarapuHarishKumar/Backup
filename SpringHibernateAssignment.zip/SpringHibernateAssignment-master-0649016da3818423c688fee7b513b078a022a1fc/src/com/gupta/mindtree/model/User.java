package com.gupta.mindtree.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Column(name="firstName")
	private String firstName;
	@Column(name="lastName")
	private String lastName;
	@Column(name="department")
	private String department;
	@Column(name="location")
	private String location;
	@Column(name="aggregate")
	private int aggregate;
	@Column(name="placed")
	private String placed;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="userId")
	private int userId;
	
	public User() {
		super();
	}

	public User(String firstName, String lastName, String department, String location, int aggregate, String placed,
			int userId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.location = location;
		this.aggregate = aggregate;
		this.placed = placed;
		this.userId = userId;
	}

	public User(String firstName, String lastName, String department, String location, int aggregate, String placed) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.location = location;
		this.aggregate = aggregate;
		this.placed = placed;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getAggregate() {
		return aggregate;
	}

	public void setAggregate(int aggregate) {
		this.aggregate = aggregate;
	}

	public String isPlaced() {
		return placed;
	}

	public void setPlaced(String placed) {
		this.placed = placed;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "User:[userId:"+getUserId()+","
				+ "firstName:"+getFirstName()+","
						+ "lastName:"+getLastName()+","
								+ "department:"+getDepartment()+","
										+ "location:"+getLocation()+","
												+ "aggregate:"+getAggregate()+","
														+ "placed:"+isPlaced()+"]";
	}

}
