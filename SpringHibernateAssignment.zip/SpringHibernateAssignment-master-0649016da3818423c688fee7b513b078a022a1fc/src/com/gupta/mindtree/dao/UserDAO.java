package com.gupta.mindtree.dao;

import java.util.List;

import com.gupta.mindtree.model.User;

public interface UserDAO {
	
	public void save(User user);
	public void update(User user);
	public void delete(User user);
	public User findById(int id);
	public List<User> findByAggregateAndDepartment(int aggregate, String department);
	public List<User> getAll();

}
