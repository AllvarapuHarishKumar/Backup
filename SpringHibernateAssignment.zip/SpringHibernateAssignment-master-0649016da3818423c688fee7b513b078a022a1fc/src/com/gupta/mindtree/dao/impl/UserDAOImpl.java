package com.gupta.mindtree.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.gupta.mindtree.dao.UserDAO;
import com.gupta.mindtree.dao.config.DAOConfig;
import com.gupta.mindtree.model.User;

public class UserDAOImpl implements UserDAO{

	@Override
	public void save(User user) {
		Session session = DAOConfig.openSession();
		Transaction tr = session.beginTransaction();
		session.save(user);
		tr.commit();
		session.close();
	}

	@Override
	public void update(User user) {
		Session session = DAOConfig.openSession();
		Transaction tr = session.beginTransaction();
		session.update(user);
		tr.commit();
		session.close();
	}

	@Override
	public void delete(User user) {
		Session session = DAOConfig.openSession();
		Transaction tr = session.beginTransaction();
		session.delete(user);
		tr.commit();
		session.close();
	}

	@Override
	public User findById(int id) {
		Session session = DAOConfig.openSession();
		User user = session.get(User.class, id);
		session.close();
		return user;
	}

	@Override
	public List<User> getAll() {
		Session session = DAOConfig.openSession();
		Query<User> query = session.createQuery("FROM User", User.class);
		List<User> users = query.getResultList();
		session.close();
		return users;
	}

	@Override
	public List<User> findByAggregateAndDepartment(int aggregate, String department) {
		Session session = DAOConfig.openSession();
		String hql = "SELECT u FROM User u WHERE u.aggregate=:aggregate AND u.department=:department";
		System.out.println(hql);
		Query<User> query = session.createQuery(hql, User.class);
		query.setParameter("aggregate", aggregate);
		query.setParameter("department", department);
		List<User> users = query.getResultList();
		session.close();
		return users;
	}

}
