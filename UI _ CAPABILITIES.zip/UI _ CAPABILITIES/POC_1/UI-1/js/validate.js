function validate()
{
	// For name
	if(document.form.name.value == ""){
		alert("Name Should Not Be Null");
		return false;
	}
	var name = document.getElementById("name").value;
	var size = name.length;
	if(size<5 || size>30){
		alert("Name Should Be Between 5 to 30 Characters");
		return false;
	}
	
    // For Highest Score
	if(document.form.comments.value == ""){
		alert("Please Enter Comments");
		return false;
	}
	var comments = document.getElementById("comments").value;
	var score = comments.length;
	if(score<20){
		alert("Oh you write something more");
		return false;
	}
	
}