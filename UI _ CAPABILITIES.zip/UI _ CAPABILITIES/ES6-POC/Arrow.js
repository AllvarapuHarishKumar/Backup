//create a set

var set = new Set();
//add three keys to the set

set.add({x: 12});
set.add(44);
set.add("text");
set.add([1,2,3]);
//check if a provided key is present

console.log(set.has("text"));

//delete a keyset.delete(44);

for(var i of set){ 
       console.log(i);
    }
    