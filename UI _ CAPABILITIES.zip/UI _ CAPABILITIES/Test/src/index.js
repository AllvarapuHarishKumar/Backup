import './style.scss';

let arrow_fun = (a) =>{
    console.log(a);
}

arrow_fun(10);