
var webpack = require('webpack')
var path = require('path')

var BUILD_DIR =path.resolve(__dirname,'public')
var APP_DIR = path.resolve(__dirname, 'src')

var config = {
entry: APP_DIR + '/index.js',
output:{
path: BUILD_DIR,
filename: 'build.js'
},

module: {
loaders: [
{
test :/\.js$/ ,
//to find the file with extension '.js'
exclude: /node_modules/ ,
loader: 'babel-loader' ,
query :{
presets :['es2015']
}
},
{
test: /\.scss$/,
loader: 'style-loader!css-loader!sass-loader'
}
]
}
}
module.exports = config 
